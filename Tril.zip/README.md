# Tril

This is a chrome extension that swaps `@realDonaldTrump` and `@dril` tweets on twitter. Inspired by https://redd.it/5xnvn9

Install the extension here: https://chrome.google.com/webstore/detail/tril/dkneemnajjjblcgpdfpmcmihdjclpopj?hl=en-US&gl=US

If you like this, tweet it!

# Where is this working

- timeline
- profile pages
- individual tweets

# Things to do

- '_____ retweeted' isn't swapped
- could probably make whole profile pages swap
- change accounts in search bar
- randomize function?

# Why would you do this

- install this on your "favorite" uncles computer and watch the fireworks
- just for giggles
